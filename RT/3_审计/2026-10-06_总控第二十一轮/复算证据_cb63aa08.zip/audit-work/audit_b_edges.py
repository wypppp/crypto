import sys,math,json,itertools
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).parents[1]/'crypto-review/RT/1_实验/发射台_前期右尾评测底座_DQ-37'))
import rule_window_infer as R
rng=np.random.default_rng(7727);out=[]
# Search synthetic 3/4-cluster designs for a p-curve incompatible with scalar bisection.
for G in [3,4]:
 W=np.array(list(itertools.product(R.WEBB,repeat=G)));w2=W*W
 for trial in range(600):
  ng=rng.integers(1,120,G).astype(float);ng[rng.integers(G)]=rng.integers(100,2000)
  vals=rng.normal(0,1,G);A=ng*vals;n=ng.sum();mean=A.sum()/n
  score=A-ng*mean;se=math.sqrt(G/(G-1)*sum(score**2))/n
  mus=np.linspace(min(vals)-4*(max(vals)-min(vals)),mean,160)
  u=A[None,:]-mus[:,None]*ng
  sums=u@W.T;mx=sums/n
  ss=np.maximum((u*u)@w2.T-2*mx*((u*ng)@W.T)+mx*mx*sum(ng*ng),0)
  den=np.sqrt(G/(G-1)*ss);tstar=np.divide(sums,den,out=np.zeros_like(sums),where=den>1e-14)
  observed=(mean-mus)/se
  ps=(1+(tstar>=observed[:,None]-1e-12).sum(1))/(len(W)+1)
  bad=np.where(np.diff(ps)<-.02)[0]
  crossing=(np.diff((ps<=.2).astype(int))==1).any()
  span=max(vals)-min(vals);lo=min(vals)-span
  y=np.repeat(vals,ng.astype(int));groups=np.repeat(np.arange(G),ng.astype(int))
  plo=R.wcr_pvalue(y,groups,lo)
  if crossing or plo>.2:
   lower=R.wcr_lower(y,groups)
   entry={'cr2_lower':R.cr2_lower(y,groups),'G':G,'ng':ng.tolist(),'values':vals.tolist(),'start_lo':lo,'p_start':plo,'lower_returned':lower,'p_returned':R.wcr_pvalue(y,groups,lower),'nonmonotone_crossing':bool(crossing)}
   if crossing:
    switches=np.where(np.diff((ps<=.2).astype(int))!=0)[0]
    entry['crossings']=[{'mu':float(mus[k]),'p':float(ps[k]),'p_next':float(ps[k+1])} for k in switches]
   entry['combined_lower']=min(entry['lower_returned'],entry['cr2_lower'])
   scan=np.linspace(entry['crossings'][0]['mu']-.03,entry['crossings'][2]['mu']+.02,250) if crossing else np.linspace(lo,lower,200)
   actual=[float(R.wcr_pvalue(y,groups,float(mu))) for mu in scan]
   accepted=[{'mu':float(mu),'p':pv} for mu,pv in zip(scan,actual) if pv>.2 and mu<entry['combined_lower']]
   entry['actual_accepted_below_combined']=accepted[::max(1,len(accepted)//5)]
   entry['actual_rejection_switches']=[{'mu':float(scan[j]),'p':actual[j],'next_mu':float(scan[j+1]),'next_p':actual[j+1]} for j in range(len(actual)-1) if (actual[j]>.2)!=(actual[j+1]>.2)]
   out.append(entry);print(json.dumps(entry),flush=True)
   if len(out)>=3:break
 if len(out)>=3:break
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))
