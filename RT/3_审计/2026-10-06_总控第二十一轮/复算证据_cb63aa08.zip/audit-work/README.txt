复算证据：固定提交 cb63aa0842ba1acd4fa3671931cedb229fb8bb6a。

解压后保持 audit-work 与 crypto-review 两个目录的位置关系。
所含项目源文件均为该提交的只读副本；不含受保护行情，C 只含已登记开发聚合结果。

Python 3.12，numpy、scipy（版本见 manifest.json）；仓库测试另需 pytest 9.1.1。

运行：
python audit-work/audit_a.py
python audit-work/audit_b.py
python audit-work/audit_b_edges.py
python -m pytest -q crypto-review/RT/1_实验/发射台_前期右尾评测底座_DQ-37/test_eval_contract.py crypto-review/RT/1_实验/发射台_前期右尾评测底座_DQ-37/test_rule_window_infer.py crypto-review/RT/1_实验/pump币_晚期龙头基础比率_DQ-18/test_exit_pair_d.py

A 的 lattice 首达、Kelly 导数二分、二项式尾反解和 Bernstein 均由独立代码复算。
B 的模拟用簇和代数化加速，三个随机例的 p 值与仓库实现逐位交叉相等。
模拟表是零假设处 WCR 与 CR2 共同拒绝的结果，没有调用已知不正确的二分区间程序。
各压力情景、外层次数、种子、权重次数和备择都见 audit_b.py / audit_b.json。
非单调反例的最终验真用仓库原函数逐点扫描，见 actual_accepted_below_combined；其他聚合扫描只用于发现候选反例。
D 未下载或重训混合 parquet；C 未读取逐币受保护数据或重跑混合 valued.csv。
