import math, sys, json, statistics, importlib
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parents[1]/'crypto-review/RT/1_实验/发射台_前期右尾评测底座_DQ-37'))
import eval_contract as E

def grow(p,K,f): return p*math.log(1+f*(K-1))+(1-p)*math.log(1-f)
def passage(p,K,N,f,target=101,lower=.1):
    states={0:1.0}; su=fl=0.0
    u,d=1+f*(K-1),1-f
    for n in range(1,N+1):
        nxt={}
        for k,pr in states.items():
            for j,q in ((k,pr*(1-p)),(k+1,pr*p)):
                wealth=math.exp(j*math.log(u)+(n-j)*math.log(d))
                if wealth>=target: su+=q
                elif wealth<lower: fl+=q
                else:nxt[j]=nxt.get(j,0)+q
        states=nxt
    return su,fl

def hk(p,K):return max(0,(p*K-1)/(2*(K-1)))
def distribution(L):
    clean=[max(0,min(1,max(L[j:]))) for j in range(len(L))]
    return clean,[1-clean[0]]+[clean[j]-(clean[j+1] if j+1<len(clean) else 0) for j in range(len(clean))]
def kelly(v,pr):
    def deriv(f):return sum(q*(r-1)/(1+f*(r-1)) for r,q in zip(v,pr))
    if deriv(0)<=0:return 0.,0.
    lo,hi=0.,.999
    if deriv(hi)>0:lo=hi
    for _ in range(100):
        mid=(lo+hi)/2
        if deriv(mid)>0:lo=mid
        else:hi=mid
    f=(lo+hi)/2
    return f,sum(q*math.log(1+f*(r-1)) for r,q in zip(v,pr))
def btail(k,n,p):return sum(math.comb(n,j)*p**j*(1-p)**(n-j) for j in range(k,n+1))
def cp(k,n,alpha):
    if k==0:return 0.
    a,b=0.,1.
    for _ in range(90):
        c=(a+b)/2
        if btail(k,n,c)<alpha:a=c
        else:b=c
    return (a+b)/2
def eb(Y,a,u,alpha,M):
    n=len(Y); l=math.log(2*M/alpha)
    return statistics.mean(Y)-math.sqrt(2*statistics.variance(Y)*l/n)-7*(u-a)*l/(3*(n-1))
res={}
res['T1']=grow(.1,13,.0125);assert abs(res['T1']-grow(.1,13,.0125))<1e-12
res['T3']=grow(.01,150,.05)
res['T4']=[.01,.3**math.ceil(math.log(101)/math.log(1.3/.3))]
res['T5']={}
for p,K,N in ((.3,1.3/.3,156),(.1,13.,1092)):
    ans=passage(p,K,N,hk(p,K));other=E.first_passage_two_point(p,K,N,E.half_kelly(p,K))
    assert max(abs(x-y) for x,y in zip(ans,other))<1e-12
    res['T5'][str((p,K,N))]=ans
steps=[0,.5,1,2,4,10,100]
for key,L in [('T6',[.4,.25,.12,.05,.015,.002]),('T7',[.4,.25,.12,.05,.02,.006])]:
    clean,pr=distribution(L);fc,gc=kelly(steps,pr)
    cert=sum(q*math.log(1+.02*(r-1)) for r,q in zip(steps,pr))
    assert abs(E.step_certificate(.02,steps,L)-cert)<1e-12
    f2,g2=E.kelly_on_distribution(steps,pr);assert abs(f2-fc)<1e-8 and abs(g2-gc)<1e-10
    res[key]={'ER':sum(q*r for r,q in zip(steps,pr)),'cert02':cert,'fc':fc,'gstar':gc,'g_half':sum(q*math.log(1+.5*fc*(r-1)) for r,q in zip(steps,pr)),'g_double':sum(q*math.log(1+2*fc*(r-1)) for r,q in zip(steps,pr))}
res['T8']={'size':btail(7,301,.01),'power':btail(7,301,.03),'cp':cp(7,301,.05),'simul_cp':[cp(k,301,.05/4) for k in [120,36,9,2]]}
assert abs(E.cp_lower(7,301,.05)-res['T8']['cp'])<1e-12
for key,R,f,cap in [('T9',[0]*700+[.5]*150+[1.5]*100+[5]*40+[30]*9+[500],.02,20),('T9b',[0]*600+[.5]*150+[1.5]*100+[5]*100+[30]*40+[500]*10,.01,50)]:
    logs=[math.log(1+f*(r-1)) for r in R];u=math.log(1+f*(cap-1));a=math.log(1-f);Y=[min(x,u) for x in logs]
    lb=eb(Y,a,u,.05,3);assert abs(E.eb_lower(Y,a,u,.05,3)-lb)<1e-12
    res[key]={'ER':statistics.mean(R),'capped_mean':statistics.mean(Y),'uncapped_g':statistics.mean(logs),'eb_lower':lb}
res['P4']=distribution([.3,.1,.25,-.1])[0]
res['P12']=kelly([0,6],[.8,.2])
res['curve']={}
pg=[.02,.05,.1,.2,.3];kg=[2,3,4,5,6,8,10,13,20,30,50,100,200]
for N in (156,520):
    curve=[]
    for p in pg:
        ans=None
        for K in kg:
            f=hk(p,K)
            if f>0 and passage(p,K,N,f)[0]>=.01:ans=K;break
        curve.append((p,ans))
    assert E.demand_curve(pg,N,.01,kg)==curve
    res['curve'][str(N)]=curve
# Jensen & stochastic dominance random checks with independently generated distributions.
import random
rng=random.Random(601006)
for _ in range(500):
    R=[rng.expovariate(1) for _ in range(30)];scale=rng.uniform(.2,1)/statistics.mean(R);f=rng.uniform(.001,.9)
    assert statistics.mean(math.log(1+f*(x*scale-1)) for x in R)<=1e-12
    L=[rng.uniform(0,1) for _ in steps[1:]];cl,pr=distribution(L);f=rng.uniform(.001,.9)
    direct=sum(q*math.log(1+f*(r-1)) for r,q in zip(steps,pr))
    assert abs(direct-E.step_certificate(f,steps,L))<1e-12
res['T2_T6b']='500 independent property trials pass'
# Valid nominal-state scenarios analogous to T10, adapted to v1.1.
def book_value(A,v):
    if 'p' not in A.pos:A.open('p',A.cash)
    A.set_value('p',v-A.cash)
A=E.Ledger();A.open('p',10000);A.set_value('p',50);A.mark(60);A.close('p');A.open('p',A.cash);A.set_value('p',50);A.mark(120);assert A.state=='PAUSED';A.resume(240,'c');assert A.D==30000;A.open('p',A.cash);A.set_value('p',15000);A.mark(270);assert A.state=='ACTIVE';A.set_value('p',0);A.mark(300);assert A.state=='STOPPED'
B=E.Ledger();B.open('p',10000);B.set_value('p',100000);B.mark(180);assert B.D==30000;B.close('p');B.open('p',B.cash);B.set_value('p',0);B.mark(270);assert B.state=='STOPPED'
C=E.Ledger();C.open('p',10000);C.set_value('p',100000);C.mark(396);assert C.D==10000
D=E.Ledger();D.open('p',10000);D.set_value('p',100000);D.mark(150);D.close('p');D.open('p',D.cash);D.set_value('p',10000);D.mark(210);assert D.state=='PAUSED';D.resume(330,'c');assert D.D==30000
for t,state in [(900,'SUCCESS'),(1125,'EXPIRED')]:
 F=E.Ledger();F.open('p',10000);F.set_value('p',1010000);F.mark(t);assert F.state==state
res['T10']='6 v1.1 nominal scenarios pass'
# Adversarial state sequences, record observations without editing project code.
def paused_locked():
 A=E.Ledger();A.open('win',10000);A.set_value('win',100000);A.mark(10);A.close('win');A.subscribe('lock',10000,20,vest_end=200);A.list_asset('lock',30,20000,200000);A.open('bad',A.cash);A.set_value('bad',0);A.mark(40);assert A.state=='PAUSED';return A
att=[]
A=paused_locked();A.resume(250,'certificate');att.append({'case':'resume after unmarked overdue write-down','state':A.state,'D':A.D,'v_loss':A.v_loss(250),'N_loss':A.n_loss(250)});A.open('new',0);att[-1]['new_open_allowed']=True
A=paused_locked();A.unlock('lock',5000);A.mark(50);att.append({'case':'unlock during pause','state':A.state,'cash':A.cash,'tradable_positions':A.pos})
A=E.Ledger();A.subscribe('x',2000,0);A.subscribe('x',2000,0);att.append({'case':'same asset subscribe twice','cash':A.cash,'v_loss':A.v_loss(1),'locked_cost':A.locked['x'].cost})
A=E.Ledger();A.subscribe('x',2000,0)
try:A.refund_arrives('x')
except TypeError as e:att.append({'case':'refund arrival before refund request','exception':type(e).__name__,'asset_exists_after_exception':'x' in A.locked,'v_loss':A.v_loss(1)})
A=E.Ledger();A.open('x',-1000);att.append({'case':'negative open accepted','cash':A.cash,'pos':A.pos})
A=E.Ledger();A.set_value('nonexistent',1100000);A.mark(1);att.append({'case':'mark nonexistent position','state':A.state,'n_liq':A.n_liq()})
A=paused_locked();A.fail_asset('lock');A.mark(50);before=A.state;A.mark(1100);att.append({'case':'permanent stopped overwritten by horizon expiry','before':before,'after':A.state})
res['attacks']=att
res['extra_boundary']={'kelly_ER_eq_1':{'values':[1.],'probs':[1.],'returned':E.kelly_on_distribution([1.],[1.]),'spec_f':0.}}
Path(__file__).with_suffix('.json').write_text(json.dumps(res,indent=2,ensure_ascii=False))
print(json.dumps(res,indent=2,ensure_ascii=False))
