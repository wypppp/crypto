import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
import math,itertools,json,sys
from pathlib import Path
import numpy as np
from scipy.stats import t as td
sys.path.insert(0,str(Path(__file__).parents[1]/'crypto-review/RT/1_实验/发射台_前期右尾评测底座_DQ-37'))
import rule_window_infer as R
S=3000;B=9999;G=23
WEBB=np.array([-math.sqrt(1.5),-1.,-math.sqrt(.5),math.sqrt(.5),1.,math.sqrt(1.5)])
w=WEBB[np.random.default_rng(20261006).integers(0,6,size=(B,G))]
w2=w*w
# Only cluster totals and sizes are needed for intercept-only WCR and CR2.
def test_stats(A,ng,mu=0):
    ng=np.asarray(ng,float);n=ng.sum();p=ng/n
    mean=A.sum(1)/n;d=A-ng[None,:]*mean[:,None]
    se1=np.sqrt(G/(G-1)*(d*d).sum(1))/n
    obs=np.divide(mean-mu,se1,out=np.where(mean>mu,np.inf,-np.inf),where=se1>1e-15)
    u=A-ng[None,:]*mu
    sm=u@w.T;mx=sm/n
    sq=u*u@w2.T;ngs=(u*ng)@w.T
    ss=np.maximum(sq-2*mx*ngs+mx*mx*(ng*ng).sum(),0)
    den=np.sqrt(G/(G-1)*ss)
    ts=np.divide(sm,den,out=np.zeros_like(sm),where=den>1e-14)
    pv=(1+(ts>=obs[:,None]-1e-12).sum(1))/(B+1)
    se2=np.sqrt(((d*d)/(1-p)).sum(1))/n
    lb=mean-td.ppf(.8,G-1)*se2
    return pv<=.2,lb>mu,pv
# Check aggregation version against the actual repository for three unbalanced examples.
rng=np.random.default_rng(901)
for k in range(3):
 ng=rng.integers(2,25,G);groups=np.repeat(np.arange(G),ng);y=rng.normal(.03,.2,len(groups))+rng.normal(0,.1,G)[groups]
 A=np.array([y[groups==g].sum() for g in range(G)])[None,:]
 p=test_stats(A,ng)[2][0];q=R.wcr_pvalue(y,groups,0,B=B)
 assert abs(p-q)<1e-12,(p,q)
# Synthetic stress laws only; no project prices or returns are used.
rng=np.random.default_rng(6100601)
ng_bal=np.full(G,40)
ng_imb=np.array([4000]+[40]*22)
scenarios=[]
# Mean-zero weekly effects, SD=.1. Within-week noise negligible relative to common effects.
for name,ng,kind in [('balanced_normal',ng_bal,'normal'),('balanced_t3',ng_bal,'t3'),('imbalanced_normal',ng_imb,'normal'),('ar1_rho_06',ng_bal,'ar')]:
 if kind=='normal':x=rng.normal(0,.1,(S,G))
 elif kind=='t3':x=rng.standard_t(3,(S,G))*.1/math.sqrt(3)
 else:
  x=np.zeros((S,G));x[:,0]=rng.normal(0,.1,S)
  for j in range(1,G):x[:,j]=.6*x[:,j-1]+rng.normal(0,.1*math.sqrt(1-.6**2),S)
 scenarios.append((name,ng,x))
# Properly centred capped-log-return laws. f=.05, Z in {0,3}, shared weekly regime.
a,b=math.log(.95),math.log(1.1)
for name,p in [('bounded_right_skew_p01',.01),('bounded_right_skew_p10',.10),('bounded_left_skew_p99',.99)]:
 z=rng.binomial(1,p,(S,G));x=(b-a-.001)*(z-p)+rng.uniform(-.0005,.0005,(S,G))
 scenarios.append((name,ng_bal,x))
# Uncapped Pareto alpha 1.5, infinite variance, centred at known mean; raw-R-upper limit is outside scope.
x=(rng.pareto(1.5,(S,G))+1-3)*.05
scenarios.append(('pareto_alpha15',ng_bal,x))
out={'setup':{'reps':S,'weights':B,'clusters':G,'alpha':.2,'seed_dgp':6100601,'seed_weights':20261006,'power_delta':.03,'ng_balanced':ng_bal.tolist(),'ng_imbalanced':ng_imb.tolist(),'gaussian_cluster_sd':.1,'bounded_log_f':.05,'bounded_log_Z':[0,3],'bounded_support_detail':'weekly log return drawn within [log(.95),log(1.1)] near either endpoint, with bounded +/-0.0005 uniform jitter; exact null mean is subtracted','crosscheck':'aggregate p-values match repository exactly on 3 random examples'},'results':[]}
for name,ng,x in scenarios:
 row={'scenario':name}
 altx=None
 if name.startswith('bounded_'):
  p0={'bounded_right_skew_p01':.01,'bounded_right_skew_p10':.1,'bounded_left_skew_p99':.99}[name]
  p1={.01:.03,.1:.2,.99:.995}[p0]
  altx=(b-a-.001)*(rng.binomial(1,p1,(S,G))-p0)+rng.uniform(-.0005,.0005,(S,G))
  row['power_alternative']={'null_hit_prob':p0,'alt_hit_prob':p1,'delta_mu':(b-a-.001)*(p1-p0)}
 for key,delta in [('size',0),('power',.03)]:
  counts=np.zeros(3,int)
  for start in range(0,S,100):
   A=((altx[start:start+100] if altx is not None else x[start:start+100]+delta) if key=='power' else x[start:start+100])*ng
   wrej,crej,pv=test_stats(A,ng)
   counts += [wrej.sum(),crej.sum(),(wrej&crej).sum()]
  row[key]=dict(zip(['wcr','cr2','take_lower_bound'],(counts/S).tolist()))
 row['combined_mc_se']=math.sqrt(row['size']['take_lower_bound']*(1-row['size']['take_lower_bound'])/S)
 out['results'].append(row);print(json.dumps(row),flush=True)
# Explicit unbalanced failure of inversion bracketing; actual repository functions.
examples=[]
for ng,yv in [([99,1],[1.,3.]),([1,99],[1.,3.]),([90,5,5],[1.,2.,3.])]:
 y=np.repeat(yv,ng);g=np.repeat(np.arange(len(ng)),ng)
 lo=y.min()-(y.max()-y.min());p=R.wcr_pvalue(y,g,lo)
 lb=R.lower_bound(y,g)
 examples.append({'sizes':ng,'cluster_values':yv,'start_lo':lo,'p_at_start_lo':p,'p_far_left':R.wcr_pvalue(y,g,-1e5),'returned':lb,'p_at_returned_wcr':R.wcr_pvalue(y,g,lb['wcr'])})
out['inversion_examples']=examples
# Zero-SE handling.
y=np.ones(G);g=np.arange(G)
with np.errstate(all='ignore'):
 out['constant_case']={'p_mu1':R.wcr_pvalue(y,g,1),'lower':R.lower_bound(y,g)}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))
print('inversion examples:',json.dumps(examples))
