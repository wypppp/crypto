import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
import sys,json,math,itertools,time
from pathlib import Path
import numpy as np
from scipy.stats import t as td
sys.path.insert(0,str(Path(__file__).parents[1]/'review-3d3d86bc/RT/1_实验/发射台_前期右尾评测底座_DQ-37'))
import rule_window_infer as R
S=3000; B=9999; N_WEEK=23; ALPHA=.2
# Reproduce the previous simulation's exact RNG position for its AR(1) scenario.
rng=np.random.default_rng(6100601)
rng.normal(0,.1,(S,23)); rng.standard_t(3,(S,23)); rng.normal(0,.1,(S,23))
x=np.zeros((S,23)); x[:,0]=rng.normal(0,.1,S)
for j in range(1,23):x[:,j]=.6*x[:,j-1]+rng.normal(0,.1*math.sqrt(1-.6**2),S)

def bm_from_counts(ng):
    n=ng.sum(); c=1/(n*np.sqrt(1-ng/n)); M=np.outer(c,c)*(np.diag(ng)-np.outer(ng,ng)/n)
    return float(np.trace(M)**2/np.trace(M@M))

def decisions(A,ng,W,delta=0):
    n=ng.sum(); G=len(ng); mean=A.sum(1)/n; d=A-ng[None,:]*mean[:,None]
    obs=mean/(np.sqrt(G/(G-1)*(d*d).sum(1))/n)
    sm=A@W.T; mx=sm/n
    sq=(A*A)@(W*W).T; ngs=(A*ng)@W.T
    ss=np.maximum(sq-2*mx*ngs+mx*mx*(ng*ng).sum(),0)
    den=np.sqrt(G/(G-1)*ss)
    ts=np.divide(sm,den,out=np.zeros_like(sm),where=den>1e-14)
    p=(1+(ts>=obs[:,None]-1e-12).sum(1))/(len(W)+1)
    se2=np.sqrt(((d*d)/(1-ng/n)).sum(1))/n
    crej=mean-td.ppf(.8,bm_from_counts(ng))*se2>0
    return np.stack([p<=ALPHA,crej,(p<=ALPHA)&crej],axis=1),p

out={'setup':{'reps':S,'weeks':23,'obs_per_week':40,'rho':.6,'stationary_sd':.1,'alpha':.2,'seed_dgp':6100601,'seed_webb':20261006,'comparison':'same previous framework: WCR test at mu0=0 AND CR2 lower bound >0; grid inversion checked separately','blocks':'consecutive nonoverlapping blocks anchored week 0; final incomplete block kept'},'results':[]}
rejections={}
for L in range(1,10):
    block=np.arange(23)//L; G=int(block.max())+1
    ng=np.bincount(block)*40.
    A=np.column_stack([x[:,block==k].sum(1)*40 for k in range(G)])
    W=R._weights(G,B,20261006)
    rej=[]; alt=[]
    for i in range(0,S,100):
        rej.append(decisions(A[i:i+100],ng,W)[0]); alt.append(decisions(A[i:i+100]+.03*ng,ng,W)[0])
    rej=np.concatenate(rej); alt=np.concatenate(alt); rejections[L]=rej
    g=np.repeat(block,40); y=np.repeat(x[0],40)
    pv=decisions(A[:1],ng,W)[1][0]; actual=R.wcr_pvalue(y,g,0,B=B)
    assert abs(pv-actual)<1e-12,(L,pv,actual)
    assert abs(R.bm_df(g)-bm_from_counts(ng))<1e-12
    size=rej.mean(0); power=alt.mean(0); p=float(size[2]); se=math.sqrt(p*(1-p)/S)
    row={'block_len':L,'clusters':G,'counts':ng.tolist(),'df_bm':bm_from_counts(ng),'weights':len(W),'size':dict(zip(['wcr','cr2','combined'],size.tolist())),'power_delta_003':dict(zip(['wcr','cr2','combined'],power.tolist())),'combined_95_mc_interval':[p-1.96*se,p+1.96*se]}
    out['results'].append(row); print(json.dumps(row),flush=True)

# Freeze block lengths using independent synthetic development histories; do not select on test outcomes.
out['independent_dev_heuristic']=[]
for ndev in (23,60,104):
    rdev=np.random.default_rng(9100600+ndev); z=np.zeros((S,ndev)); z[:,0]=rdev.normal(0,.1,S)
    for j in range(1,ndev):z[:,j]=.6*z[:,j-1]+rdev.normal(0,.1*math.sqrt(1-.6**2),S)
    lengths=np.array([R.choose_block_len(row) for row in z]); rr=np.array([rejections[int(L)][i,2] for i,L in enumerate(lengths)])
    p=float(rr.mean()); se=math.sqrt(p*(1-p)/S)
    row={'development_weeks':ndev,'block_len_histogram':{str(k):int((lengths==k).sum()) for k in range(1,10)},'combined_size':p,'combined_95_mc_interval':[p-1.96*se,p+1.96*se]}
    out['independent_dev_heuristic'].append(row); print(json.dumps(row),flush=True)
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))
