Review target: wypppp/crypto at 3d3d86bc4b5ffb8cf50cf432251412ab48be9a0d.
Read-only source whitelist: eval_contract.py, test_eval_contract.py, eval_contract_vectors.py, rule_window_infer.py, test_rule_window_infer.py, merged contract and inference method, and specified audit specifications. No price files, protected samples, queries or trading APIs were used.

Run from the extracted evidence root (numpy, scipy and pytest required):
python fix-audit/check_a.py
python fix-audit/check_b.py
python fix-audit/sim_ar1.py
python -m pytest -q review-3d3d86bc/RT/1_实验/发射台_前期右尾评测底座_DQ-37/test_eval_contract.py review-3d3d86bc/RT/1_实验/发射台_前期右尾评测底座_DQ-37/test_rule_window_infer.py

check_a: all seven previous ledger sequences plus Kelly boundary; targeted variants exercise the same unique-ID and confirmation-certificate requirements. Original sequences pass; literal suffix collisions still destroy value.
check_b: all three previous nonmonotonic examples, default and fine grids; shifted first example contradicts a positive lower bound; observed/bootstrap zero variance; lower-endpoint guard; independent observation-level BM matrix calculation.
sim_ar1: exactly reproduces the previous audit_b.py RNG position and AR(1) sequence. Synthetic data only. For comparison with the previous review, reports direct null-test rejection by WCR AND CR2 (with new BM df), not full-grid inversion rejection. Counts reflect nonoverlapping blocks at a frozen calendar origin, retaining the final incomplete block. Independent synthetic development histories determine block lengths; test outcomes do not choose lengths. Fixed L=1..9 results are sensitivity results, not permission to choose a passing length.

source_manifest.json records the exact Git blob SHA and local SHA256 of the audited files. The fixed-commit source copies match these Git blobs byte-for-byte. Prior audit_b.py is included only as a framework reference, not as an entrypoint.
