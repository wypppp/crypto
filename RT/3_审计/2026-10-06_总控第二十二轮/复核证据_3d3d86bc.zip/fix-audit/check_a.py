import sys, math, json, copy
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parents[1]/'review-3d3d86bc/RT/1_实验/发射台_前期右尾评测底座_DQ-37'))
import eval_contract as E

def paused_locked():
    a=E.Ledger(); p=a.open('win',10000); a.set_value(p,100000); a.mark(10); a.close(p)
    lid=a.subscribe('lock',10000,20,vest_end=200); a.list_asset(lid,30,20000,200000)
    p=a.open('bad',a.cash); a.set_value(p,0); a.mark(40)
    assert a.state=='PAUSED'; return a,lid

def snap(a,t=1):
    return {'state':a.state,'cash':a.cash,'D':a.D,'positions':dict(a.pos),'locked_ids':list(a.locked),'v_loss':a.v_loss(t),'n_loss':a.n_loss(t)}

def rejected(fn):
    try: fn()
    except (ValueError,KeyError,RuntimeError) as e: return type(e).__name__+': '+str(e)
    return None

out={}
a,l=paused_locked(); e=rejected(lambda:a.resume(250,{'policy':'dev','data_start':50,'data_end':240})); out['1_resume_overdue']={'error':e,**snap(a,250)}; assert e and a.state=='STOPPED'
a,l=paused_locked(); a.unlock(l,5000); a.mark(50); out['2_unlock_paused']=snap(a,50); assert a.cash==5000 and not a.pos
a=E.Ledger(); x=a.subscribe('x',2000,0); x2=a.subscribe('x',2000,0); out['3_same_name']={'returned_ids':[x,x2],**snap(a)}; assert a.v_loss(1)==10000
a=E.Ledger(); x=a.subscribe('x',2000,0); before=snap(a); e=rejected(lambda:a.refund_arrives(x)); out['4_refund_no_request']={'error':e,'unchanged':snap(a)==before}; assert e and snap(a)==before
a=E.Ledger(); before=snap(a); e=rejected(lambda:a.open('x',-1000)); out['5_negative_open']={'error':e,'unchanged':snap(a)==before}; assert e and snap(a)==before
a=E.Ledger(); before=snap(a); e=rejected(lambda:a.set_value('nonexistent',1100000)); a.mark(1); out['6_nonexistent_value']={'error':e,**snap(a)}; assert e and a.state=='ACTIVE' and a.v_loss(1)==10000
a,l=paused_locked(); a.fail_asset(l); a.mark(50); before=a.state; a.mark(1100); out['7_stop_expiry']={'before':before,'after':a.state}; assert before==a.state=='STOPPED'
out['kelly_boundary']=[{'values':v,'probs':p,'returned':E.kelly_on_distribution(v,p)} for v,p in [([1],[1]),([0,2],[.5,.5]),([0,.5],[.5,.5]),([0,3],[.5,.5])]]
assert all(x['returned']==(0.,0.) for x in out['kelly_boundary'][:3])
# The same original defect: IDs must be globally unique, including literal generated-looking names.
a=E.Ledger(); ids=[a.subscribe('x',2000,0),a.subscribe('x#2',2000,0),a.subscribe('x',2000,0)]
out['3_extension_suffix_collision']={'returned_ids':ids,**snap(a)}
a=E.Ledger(); p=a.open('x',1000); p2=a.open('x#2',1000); p3=a.open('x',1000)
out['3_extension_position_collision']={'returned_ids':[p,p2,p3],**snap(a)}
a,l=paused_locked(); e=rejected(lambda:a.resume(150,{'policy':'dev','data_start':50,'data_end':140,'channel':'C2','passed':False})); out['certificate_explicit_failure']={'error':e,**snap(a,150)}
for amount in [float('nan'),float('inf'),-float('inf'),-1]:
    a=E.Ledger(); before=snap(a); assert rejected(lambda:a.open('z',amount)) and snap(a)==before
out['nonfinite_amounts']='all rejected, ledger unchanged'
Path(__file__).with_suffix('.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)); print(json.dumps(out,ensure_ascii=False,indent=2))
