import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
import sys, math, json, itertools
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).parents[1]/'review-3d3d86bc/RT/1_实验/发射台_前期右尾评测底座_DQ-37'))
import rule_window_infer as R

examples=[([58,163,109],[-.3051232980125395,1.8130407228147216,.21026510297521808]),([1355,67,71],[.7761206177828804,.21663966411737898,.5152473437926675]),([113,1331,12],[.27993952031701075,.3175031083567621,.21369988292213388])]
out={'three_cluster_examples':[]}
for ng,v in examples:
    y=np.repeat(v,ng); g=np.repeat(np.arange(3),ng)
    actual=R.lower_bound(y,g)
    fine=R.wcr_lower(y,g,n_grid=20001)
    out['three_cluster_examples'].append({'ng':ng,'values':v,'default':actual,'fine_grid':fine})
out['zero_observed_variance']=R.lower_bound([.1]*12,np.repeat(np.arange(4),3))
out['unequal_two_clusters']=R.lower_bound(np.repeat([1.,3.],[99,1]),np.repeat([0,1],[99,1]))
# The original three-cluster counterexample shifted by .06: the default grid can falsely claim a positive lower bound.
ng,v=examples[0]; y=np.repeat(np.array(v)+.06,ng); g=np.repeat(np.arange(3),ng)
out['shifted_three_cluster_grid_false_positive']={'shift':.06,'p_at_zero':R.wcr_pvalue(y,g,0),'default':R.lower_bound(y,g),'fine_grid':R.wcr_lower(y,g,n_grid=20001)}
# Independent Bell-McCaffrey matrix from the observation-level projection.
ng=np.array([100,2,2,2,2,2]); g=np.repeat(np.arange(6),ng); n=len(g)
J=np.ones((n,n))/n; H=np.eye(n)-J
C=np.column_stack([H@((g==k)/math.sqrt(1-ng[k]/n)/n) for k in range(6)])
M=C.T@C; df=float(np.trace(M)**2/np.trace(M@M))
out['bm_df_independent']={'observation_matrix':df,'repo':R.bm_df(g)}; assert abs(df-R.bm_df(g))<1e-12
# Bootstrap zero denominator with a nonzero numerator should not become t*=0.
y=np.array([1.,math.sqrt(.5)]); g=[0,1]; W=R._weights(2,9999,20261006)
vals=[]; zeros=[]
for k,w in enumerate(W):
    z=w*y; mean=float(z.mean()); se=abs(float(z[0]-z[1]))/2
    if se==0 and mean!=0: zeros.append({'weight':w.tolist(),'bootstrap_mean':mean})
    vals.append(mean/se if se>0 else (math.copysign(math.inf,mean) if mean else 0.))
obs=float(y.mean())/(abs(y[0]-y[1])/2)
p=(1+sum(z>=obs-1e-12 for z in vals))/(1+len(W))
out['bootstrap_zero_variance']={'repo_p':R.wcr_pvalue(y,g,0),'independent_p_with_signed_infinity':p,'zero_draws':zeros}
# Force the documented endpoint guard without altering the source's behavior.
out['endpoint_guard']=R.wcr_lower([1.,3.],[0,1],span_se=.01)
# Deliberately thin accepted island: grid can miss original counterexample #3's isolated acceptance region.
out['block_length_examples']={'constant':R.choose_block_len([0]*30),'alternating':R.choose_block_len([1,-1]*10)}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)); print(json.dumps(out,ensure_ascii=False,indent=2))
